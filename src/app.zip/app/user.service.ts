import {UserModel} from './userModel';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  

  APIURL = 'http://localhost:2000/';

  constructor(private _http:HttpClient) { }
  getAllUsers():Observable<any>{
  return this._http.get(this.APIURL+'users');
  }
  addUser(user: UserModel){
    return this._http.post(this.APIURL + 'users', user).subscribe();
  }
}
