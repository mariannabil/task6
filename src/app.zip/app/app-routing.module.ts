
import { registerLocaleData } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './pages/about/about.component';
import { HomeComponent } from './pages/home/home.component';
import { RegisterComponent } from './register/register.component';
import { TempleteFormComponent } from './templete-form/templete-form.component';
import {AllUserComponent} from './all-user/all-user.component';
import {AddUserComponent} from './add-user/add-user.component'


const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"about",component:AboutComponent},
  {path:"register", component:RegisterComponent},
  {path:"templeteForm",component:TempleteFormComponent},
  {path:"allUser" ,component:AllUserComponent,pathMatch:'full'},
  {path:"addUser", component:AddUserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
