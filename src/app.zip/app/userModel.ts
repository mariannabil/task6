export class UserModel {
    // "_id":string;
   "Title" : string;
  "firstName": string;
    "lastName": string;
    "Email":string;
    "password":number;
 "confirmPassword":number
}