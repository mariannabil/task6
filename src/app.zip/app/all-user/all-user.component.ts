 import {UserService} from './../user.service';
// import{UserModel} from './../userModel';
import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-all-user',
  templateUrl: './all-user.component.html',
  styleUrls: ['./all-user.component.css']
})
export class AllUserComponent implements OnInit {
users=[]
    constructor(private user:UserService) { }
 

  ngOnInit(): void {
  
    this.getAll();

 }
    
  
  

getAll(){
  this.user.getAllUsers().subscribe(
    data => this.users =data
  );
}
}
